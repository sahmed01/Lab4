/*****************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
* This is the top level application for the PSoC 4 BLE Lab 4.
*
* Hardware Dependency:
* CY8CKIT-042 BLE Pioneer Kit
*
******************************************************************************
* Copyright (2014), Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/


/*****************************************************************************
* Included headers
*****************************************************************************/
#include <main.h>
#include <BLEApplications.h>

#define CapSense_PROXIMITYSENSOR0_PROX
/*****************************************************************************
* Function Prototypes
*****************************************************************************/
static void InitializeSystem(void);
static void HandleCapSenseProximity(void);


/*****************************************************************************
* Public functions
*****************************************************************************/

/*******************************************************************************
* Function Name: main
********************************************************************************
* Summary:
* System entrance point. This calls the initializing function and continuously
* process BLE and CapSense events.
*
* Parameters:
*  void
*
* Return:
*  int
*
*******************************************************************************/
int main()
{
	/* This function will initialize the system resources such as BLE and CapSense */
    InitializeSystem();
	
    for(;;)
    {
        /*Process event callback to handle BLE events. The events generated and 
		* used for this application are inside the 'CustomEventHandler' routine*/
        CyBle_ProcessEvents();
		
		if(TRUE == deviceConnected)
		{
            /* When the Client Characteristic Configuration descriptor (CCCD) is
             * written by Central device for enabling/disabling notifications, 
             * then the same descriptor value has to be explicitly updated in 
             * application so that it reflects the correct value when the 
             * descriptor is read */
			UpdateNotificationCCCD();
			
			/* Send CapSense Proximity data when respective notification is enabled */
			if(TRUE)
			{
				/* Check for CapSense Proximity swipe and send data accordingly */
				HandleCapSenseProximity();
			}
		}
    }	
}


/*******************************************************************************
* Function Name: InitializeSystem
********************************************************************************
* Summary:
* Start the components and initialize system.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void InitializeSystem(void)
{
	/* Enable global interrupt mask */
	CyGlobalIntEnable; 
		
	/* Start BLE component and register the CustomEventHandler function. This 
	 * function exposes the events from BLE component for application use */
    CyBle_Start(CustomEventHandler);	
    
	/* Start both the PrISM components for LED control*/
    PRS_1_Start();
    PRS_2_Start();
	
	/* The RGB LED on BLE Pioneer kit are active low. Drive HIGH on 
	 * pin for OFF and drive LOW on pin for ON*/
	PRS_1_WritePulse0(RGB_LED_OFF);
	PRS_1_WritePulse1(RGB_LED_OFF);
	PRS_2_WritePulse0(RGB_LED_OFF);
	
	/* Set Drive mode of output pins from HiZ to Strong */
	RED_SetDriveMode(RED_DM_STRONG);
	GREEN_SetDriveMode(GREEN_DM_STRONG);
	BLUE_SetDriveMode(BLUE_DM_STRONG);
	
	/* Initialize CapSense component and initialize baselines*/
	CapSense_Start();
	CapSense_InitializeAllBaselines();
}


/*******************************************************************************
* Function Name: HandleCapSenseProximity
********************************************************************************
* Summary:
* This function scans for finger position on CapSense Proximity, and if the  
* position is different, triggers separate routine for BLE notification.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void HandleCapSenseProximity(void)
{
	/* Last read CapSense Proximity position value */
	static uint16 lastPosition;	
	
	/* Present Proximity position read by CapSense */
	uint16 ProximityPosition;
		
	/* Update CapSense baseline for next reading*/
	CapSense_UpdateEnabledBaselines();	
		
	/* Scan the Proximity widget */
	CapSense_ScanEnabledWidgets();
    CapSense_EnableWidget(CapSense_PROXIMITYSENSOR0__PROX);
    
	/* Wait for CapSense scanning to be complete. This could take about 5 ms */
    while(CapSense_IsBusy());
	
	/* Read the finger position on the Proximity */
	ProximityPosition = CapSense_GetDiffCountData(CapSense_PROXIMITYSENSOR0__PROX);	

	/*If finger is detected on the Proximity*/
	if((ProximityPosition != NO_FINGER) && (ProximityPosition <= Proximity_MAX_VALUE))
	{
        /* If finger position on the Proximity is changed then send data as BLE 
         * notifications */
        if(ProximityPosition != lastPosition)
		{
			/* Update global variable with present finger position on Proximity*/
			lastPosition = ProximityPosition;

			SendCapSenseNotification((uint8)ProximityPosition);

		}	
	}	
}

#include <project.h>
#include <stdbool.h>
#include "main.h"
#include "HeartRateProcessing.h"
#include "BleProcessing.h"
#include "WatchdogTimer.h"


#define TIME_SINCE_CONNECTED_MS         (5000)


static CYBLE_GAP_CONN_UPDATE_PARAM_T hrmConnectionParam =
{
    16,         /* Minimum connection interval of 20 ms */
    16,         /* Maximum connection interval of 20 ms */
    49,         /* Slave latency of 49 */
    500         /* Supervision timeout of 5 seconds */
};

static void InitializeSystem(void)
{
    #if (RGB_LED_IN_PROJECT)
        /* Turn off all LEDs */
        Led_Advertising_Green_Write(1);
        Led_Connected_Blue_Write(1);
    #endif  /* #if (RGB_LED_IN_PROJECT) */

    /* Enabling Global interrupts */
    CyGlobalIntEnable; 
	
    /* Start Opamp and ADC components and PWM component */
	Opamp_Start();
    	ADC_Start();
	PWM_Start();
    
    /* Start BLE component */
    CyBle_Start(GeneralEventHandler);
    
    
    /* Register the Heart Rate Service event handler callback. The function
     * to be registered is HrsEventHandler().
     */
	CyBle_HrsRegisterAttrCallback(HrsEventHandler);
    
    
    /* Start the Watchdog Timer */
	WatchdogTimer_Start();
}

int main()
{
    static uint32 previousTimestamp = 0;
    static uint32 currentTimestamp = 0;
    CYBLE_LP_MODE_T bleMode;
    uint8 interruptStatus;
    
    /* Initialize all blocks of the system */
	InitializeSystem();
    
    /* Run forever */
    for(;;)
    {
        /* Wake up ADC from low power mode */
        ADC_Wakeup();
        
        /* Analog Front End. 
         * Detects the input signal and measures Heart Rate 
         */
        ProcessHeartRateSignal();

        /* Put ADC in low power mode */
        ADC_Sleep();
        
        /* Measure the current system timestamp from watchdog timer */
        currentTimestamp = WatchdogTimer_GetTimestamp();        

        /* Update BLE connection parameters a few seconds after connection */
        if((CyBle_GetState() == CYBLE_STATE_CONNECTED) && 
           (connParamRequestState == CONN_PARAM_REQUEST_NOT_SENT))
        {
            if((currentTimestamp - timestampWhenConnected) > TIME_SINCE_CONNECTED_MS)
            {
                CyBle_L2capLeConnectionParamUpdateRequest(cyBle_connHandle.bdHandle, &hrmConnectionParam);
                connParamRequestState = CONN_PARAM_REQUEST_SENT;
            }
        }
        
        
        if((currentTimestamp - previousTimestamp) >= 1000)
        {
            /* Call API defined in BleProcessing.c to send 
             * notification over BLE.
             */
            SendHeartRateOverBLE();
            
            /* Update the previous timestamp with the current timestamp. */
            previousTimestamp = currentTimestamp;
        }

        /* Try to stay in low power mode until the next watchdog interrupt */
        while(WatchdogTimer_GetTimestamp() == currentTimestamp)
        {
            /* Process any pending BLE events */
            CyBle_ProcessEvents();
            
//            /* Request the BLE block to enter Deep Sleep */
//            bleMode = CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);

            
//            interruptStatus = CyEnterCriticalSection();
//            
//            /* Check if the BLE block entered Deep Sleep */
//            if(CYBLE_BLESS_DEEPSLEEP == bleMode)
//            {
                
//                if((CyBle_GetBleSsState() == CYBLE_BLESS_STATE_ECO_ON) ||
//                   (CyBle_GetBleSsState() == CYBLE_BLESS_STATE_DEEPSLEEP))
//                {
//                    CySysPmDeepSleep();
//                }
//            }
//           /* The else condition signifies that the BLE block cannot enter 
//             * Deep Sleep and is in Active mode.  
//             */
//            else
//            {
                

                if(CyBle_GetBleSsState() != CYBLE_BLESS_STATE_EVENT_CLOSE)
                {
                    CySysPmSleep();
                }
            }
            
            /* Exit Critical section - Global interrupts are enabled again */
            CyExitCriticalSection(interruptStatus);
        }

        if(enterHibernateFlag)
        {
            /* Stop the BLE component */
            CyBle_Stop();
            
            /* Enable the Hibernate wakeup functionality */
            SW2_Switch_ClearInterrupt();
            Wakeup_ISR_Start();
            
            #if (RGB_LED_IN_PROJECT)
                /* Turn off Green and Blue LEDs to indicate Hibernate */
                Led_Advertising_Green_Write(1);
                Led_Connected_Blue_Write(1);
                
                /* Change the GPIO state to High-Z */
                Led_Advertising_Green_SetDriveMode(Led_Advertising_Green_DM_ALG_HIZ);
                Led_Connected_Blue_SetDriveMode(Led_Connected_Blue_DM_ALG_HIZ);
            #endif  /* #if (RGB_LED_IN_PROJECT) */
            
            /* Enter hibernate mode */
            CySysPmHibernate();
        }
    }

/* [] END OF FILE */
